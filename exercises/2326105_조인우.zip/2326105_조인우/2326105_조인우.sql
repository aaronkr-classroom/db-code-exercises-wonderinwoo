-- DB Final Project
-- Student Name: 조인우
-- Student ID: 2326105


-- 1. CREATE TABLE
-- 필수 구현
-- 1. class_code
CREATE TABLE class_code (
    code NUMERIC(1) PRIMARY KEY,
    class VARCHAR(10),
    basis VARCHAR(20)
);

-- 2. task_code
CREATE TABLE task_code (
    code NUMERIC(1) PRIMARY KEY,
    task VARCHAR(30)
);

-- 3. customer
CREATE TABLE customer (
    cus_id VARCHAR(15) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    cell CHAR(13) NOT NULL UNIQUE,
    addr VARCHAR(100),
    c_code NUMERIC(1) DEFAULT 3,
    FOREIGN KEY (c_code) REFERENCES class_code(code)
);

-- 4. staff
CREATE TABLE staff (
    staff_id NUMERIC(5) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday NUMERIC(6) NOT NULL,
    tel CHAR(12),
    salary NUMERIC(9),
    t_code NUMERIC(1) NOT NULL,
    hire_date CHAR(8) NOT NULL,
    FOREIGN KEY (t_code) REFERENCES task_code(code)
);

-- 5. tour
CREATE TABLE tour (
    tour_num CHAR(8) PRIMARY KEY,
    departure VARCHAR(50) NOT NULL,
    arrival VARCHAR(50) NOT NULL,
    program VARCHAR(100),
    start_dt DATE NOT NULL,
    end_dt DATE NOT NULL,
    min_num NUMERIC(2),
    max_num NUMERIC(2),
    expense NUMERIC(7) NOT NULL,
    deposit NUMERIC(6),
    dept_yn CHAR(1) DEFAULT 'N',
    staff_id NUMERIC(5),
    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);

-- 6. reserve
CREATE TABLE reserve (
    cus_id VARCHAR(15),
    tour_num CHAR(8),
    res_date CHAR(8) DEFAULT TO_CHAR(CURRENT_DATE, 'YYYYMMDD'),
    dep_yn CHAR(1) DEFAULT 'N',
    exp_yn CHAR(1) DEFAULT 'N',
    PRIMARY KEY (cus_id, tour_num),
    FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- 5. BONUS TABLES (Optional)
-- 보너스 구현
-- 1. driver
CREATE TABLE driver (
    driver_id NUMERIC(5) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday CHAR(6) NOT NULL,
    cell CHAR(13) NOT NULL,
    pay NUMERIC(5) DEFAULT 15000,
    cont_date CHAR(8),
    cont_term CHAR(8)
);

-- 2. tour_bus
CREATE TABLE tour_bus (
    bus_id NUMERIC(2) PRIMARY KEY,
    seat NUMERIC(2),
    del_year NUMERIC(4)
);

-- 3. assign_driver
CREATE TABLE assign_driver (
    tour_num CHAR(8) PRIMARY KEY,
    driver_id NUMERIC(5),
    work_hour NUMERIC(3),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

-- 4. assign_bus
CREATE TABLE assign_bus (
    tour_num CHAR(8) PRIMARY KEY,
    bus_id NUMERIC(2),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (bus_id) REFERENCES tour_bus(bus_id)
);

-------------------------------------------------------------------
-- 2. INSERT DATA
-- 필수 구현 INSERT
-- 1. class_code (실습문제에서는 3개의 등급코드로 지정하고 있어 예외적으로 5개가 아닌 3개로 구성하였음)
INSERT INTO class_code VALUES 
(1, '최우수', '연 결제액 500만원 이상'),
(2, '우수', '연 결제액 300만원 이상'),
(3, '일반', '신규 및 기본 고객');

-- 2. task_code
INSERT INTO task_code VALUES 
(1, '여행상품관리'),
(2, '예약관리'),
(3, '관광버스배차관리'),
(4, '직원관리'),
(5, '고객관리');

-- 3. customer
INSERT INTO customer VALUES 
('user01', '김철수', '010-1111-2222', '서울특별시 강남구', 1),
('user02', '이영희', '010-3333-4444', '부산광역시 해운대구', 2),
('user03', '박민수', '010-5555-6666', '충청북도 충주시', 3),
('user04', '최지윤', '010-7777-8888', '대구광역시 수성구', 3),
('user05', '정대호', '010-9999-0000', '광주광역시 북구', 2);

-- 4. staff
INSERT INTO staff VALUES 
(10001, '강호동', 800101, '010-123-5678', 3500000, 1, '20200301'),
(10002, '유재석', 820505, '010-234-6789', 3200000, 2, '20210401'),
(10003, '신동엽', 851212, '010-345-7890', 4000000, 3, '20190101'),
(10004, '이수근', 880707, '010-456-8901', 2800000, 4, '20220501'),
(10005, '전현무', 900909, '010-567-9012', 3000000, 5, '20230601');

-- 5. tour
INSERT INTO tour VALUES 
('T2026001', '서울', '제주도', 'http://tour.com/jeju', '2026-07-01', '2026-07-04', 10, 30, 450000, 45000, 'Y', 10001),
('T2026002', '부산', '울릉도', 'http://tour.com/ulleung', '2026-08-10', '2026-08-12', 15, 40, 350000, 35000, 'N', 10001),
('T2026003', '서울', '강릉', 'http://tour.com/gangneung', '2026-09-05', '2026-09-06', 20, 45, 150000, 15000, 'Y', 10002),
('T2026004', '대전', '여수', 'http://tour.com/yeosu', '2026-10-01', '2026-10-03', 10, 25, 250000, 25000, 'N', 10002),
('T2026005', '광주', '경주', 'http://tour.com/gyeongju', '2026-11-15', '2026-11-17', 20, 40, 200000, 20000, 'Y', 10001);

-- 6. reserve
INSERT INTO reserve VALUES 
('user01', 'T2026001', '20260501', 'Y', 'N'),
('user02', 'T2026001', '20260502', 'Y', 'Y'),
('user03', 'T2026003', '20260610', 'Y', 'N'),
('user04', 'T2026004', '20260715', 'N', 'N'),
('user05', 'T2026005', '20260820', 'Y', 'Y');

-- 보너스 구현 INSERT
-- 1. driver
INSERT INTO driver VALUES 
(20001, '김기사', '750303', '010-1111-0001', 18000, '20210101', '24'),
(20002, '이운전', '800404', '010-2222-0002', 16000, '20220301', '12'),
(20003, '박차장', '820505', '010-3333-0003', 15000, '20230501', '12'),
(20004, '최핸들', '780606', '010-4444-0004', 17000, '20200801', '36'),
(20005, '정바퀴', '850707', '010-5555-0005', 15000, '20240101', '6');

-- 2. tour_bus
INSERT INTO tour_bus VALUES 
(11, 45, 2019),
(12, 28, 2021),
(13, 45, 2020),
(14, 28, 2022),
(15, 45, 2023);

-- 3. assign_driver
INSERT INTO assign_driver VALUES 
('T2026001', 20001, 30),
('T2026002', 20002, 24),
('T2026003', 20003, 16),
('T2026004', 20004, 20),
('T2026005', 20005, 18);

-- 4. assign_bus
INSERT INTO assign_bus VALUES 
('T2026001', 11),
('T2026002', 12),
('T2026003', 13),
('T2026004', 14),
('T2026005', 15);

-------------------------------------------------------------------
-- 3. INDEX
CREATE INDEX tour_arrival_idx ON tour(arrival);
CREATE INDEX driver_name_idx ON driver(name);

-------------------------------------------------------------------

--만든 테이블 조회--
-- 1. 고객등급코드 테이블 조회
SELECT * FROM class_code;
-- 2. 직원업무코드 테이블 조회
SELECT * FROM task_code;
-- 3. 고객 테이블 조회
SELECT * FROM customer;
-- 4. 직원 테이블 조회
SELECT * FROM staff;
-- 5. 여행상품 테이블 조회
SELECT * FROM tour;
-- 6. 예약하다 테이블 조회
SELECT * FROM reserve;
-- 7. 관광버스 테이블 조회
SELECT * FROM tour_bus;
-- 8. 운전기사 테이블 조회
SELECT * FROM driver;
-- 9. 기사배정하다 테이블 조회
SELECT * FROM assign_driver;
-- 10. 차량배정하다 테이블 조회
SELECT * FROM assign_bus;

-- 4. TEST QUERIES
-- 1. Customer Grade Search (고객 등급 검색)
SELECT c.name, cc.class 
FROM customer c
JOIN class_code cc ON c.c_code = cc.code
WHERE c.cus_id = 'user01';

-- 2. Employee Task Search (직원 담당업무 검색)
SELECT s.name, tc.task 
FROM staff s
JOIN task_code tc ON s.t_code = tc.code
WHERE s.staff_id = 10001;

-- 3. Tour Reservation Search (예약상품 예약 고객 검색)
SELECT c.name, r.res_date, r.dep_yn 
FROM reserve r
JOIN customer c ON r.cus_id = c.cus_id
WHERE r.tour_num = 'T2026001';

-- 4. Assigned Driver Search (여행상품 배정 운전기사 검색)
SELECT t.departure, d.name, d.cell 
FROM assign_driver ad
JOIN tour t ON ad.tour_num = t.tour_num
JOIN driver d ON ad.driver_id = d.driver_id
WHERE ad.tour_num = 'T2026001';

-- 5. INSERT example (신규 고객 등록)
INSERT INTO customer (cus_id, name, cell) 
VALUES ('user06', '조인우', '010-0000-1111');

-- 6. UPDATE example (직원 급여 수정)
UPDATE staff 
SET salary = salary + 200000 
WHERE staff_id = 10005;

-- 7. DELETE example (예약 정보 삭제)
DELETE FROM reserve 
WHERE cus_id = 'user04' AND tour_num = 'T2026004';
